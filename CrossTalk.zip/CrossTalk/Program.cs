﻿
Reciter.ReciteAllTheWords();

Console.WriteLine("Reciting Completed (press any key to close App)...");
Console.ReadLine();
